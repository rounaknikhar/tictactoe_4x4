
import java.awt.Color;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lynx
 */
public class Grid extends javax.swing.JFrame {
 //   private String turn= "X";
    /**
     * Creates new form Grid
     */
    
    public Grid() {
        initComponents();
        setSize(800,1000);
        setResizable(false);
        
    }
    
    move moveObject = new move();
    
    private void go() {
      String t = jLabel3.getText();  
      if ((move.getTurn().equals("O")) && (t.equals("X"))) 	       	    	    		       	     	
      {	 	
        jLabel3.setText("O");
      }	 	       	    	    		       	     	
      else	 	       	    	    		       	     	
      {	 	       	    	    		       	     	
        jLabel3.setText("X");
      }
    }
   
   /* 
    if (all cells have been filled)
        if (there is a winner)
            announce the winner
        else 
            announce stalemate
    else 
            if (there is a winner)
                ....
            */
    
    private void winner(){
       
        if ((("X".equals(jButton1.getText()) || "O".equals(jButton1.getText()) == true) &&
            ("X".equals(jButton2.getText()) || "O".equals(jButton2.getText()) == true) &&
            ("X".equals(jButton3.getText()) || "O".equals(jButton3.getText()) ==true) &&
            ("X".equals(jButton4.getText()) || "O".equals(jButton4.getText()) == true) && 
            ("X".equals(jButton5.getText()) || "O".equals(jButton5.getText()) == true) &&
            ("X".equals(jButton6.getText()) || "O".equals(jButton6.getText()) == true) &&
            ("X".equals(jButton7.getText()) ||  "O".equals(jButton7.getText()) == true) &&
            ("X".equals(jButton8.getText()) ||  "O".equals(jButton8.getText()) == true) &&
            ("X".equals(jButton9.getText()) ||  "O".equals(jButton9.getText()) == true) &&   
            ("X".equals(jButton10.getText()) || "O".equals(jButton10.getText()) == true) &&
            ("X".equals(jButton11.getText()) || "O".equals(jButton11.getText()) == true) &&
            ("X".equals(jButton12.getText()) || "O".equals(jButton12.getText()) == true) &&
            ("X".equals(jButton13.getText()) || "O".equals(jButton13.getText()) == true) &&
            ("X".equals(jButton14.getText()) ||  "O".equals(jButton14.getText()) == true) &&       
            ("X".equals(jButton15.getText()) ||  "O".equals(jButton15.getText()) == true) &&
            ("X".equals(jButton16.getText()) ||  "O".equals(jButton16.getText()) == true)) )
        { 
            
            
            jLabel4.setText("Stalemate");
            jLabel2.setText(" ");
            jLabel3.setText(" ");
            
        }
            if 
                    ( 
                    (("X".equals(jButton1.getText())) && ("X".equals(jButton5.getText())) && ("X".equals(jButton9.getText())) && ("X".equals(jButton13.getText()))) ||
                    (("X".equals(jButton1.getText())) && ("X".equals(jButton2.getText())) && ("X".equals(jButton3.getText())) && ("X".equals(jButton4.getText()))) ||
                    (("X".equals(jButton2.getText())) && ("X".equals(jButton6.getText())) && ("X".equals(jButton10.getText())) && ("X".equals(jButton14.getText()))) ||
                    (("X".equals(jButton3.getText())) && ("X".equals(jButton7.getText())) && ("X".equals(jButton11.getText())) && ("X".equals(jButton15.getText()))) ||
                    (("X".equals(jButton4.getText())) && ("X".equals(jButton8.getText())) && ("X".equals(jButton12.getText())) && ("X".equals(jButton16.getText()))) ||
                    (("X".equals(jButton5.getText())) && ("X".equals(jButton6.getText())) && ("X".equals(jButton7.getText())) && ("X".equals(jButton8.getText()))) ||
                    (("X".equals(jButton9.getText())) && ("X".equals(jButton10.getText()))&&("X".equals(jButton11.getText())) && ("X".equals(jButton12.getText()))) ||
                    (("X".equals(jButton13.getText()))&& ("X".equals(jButton14.getText()))&&("X".equals(jButton15.getText())) && ("X".equals(jButton16.getText()))) ||
                    (("X".equals(jButton1.getText())) && ("X".equals(jButton6.getText())) &&("X".equals(jButton11.getText())) && ("X".equals(jButton16.getText()))) ||
                    (("X".equals(jButton4.getText())) && ("X".equals(jButton7.getText())) && ("X".equals(jButton10.getText())) && ("X".equals(jButton13.getText()))) ||
                    (("X".equals(jButton1.getText())) && ("X".equals(jButton5.getText())) && ("X".equals(jButton9.getText())) && ("X".equals(jButton13.getText()))) 
                    )
            {
            jLabel4.setText("Player X wins");
            jLabel2.setText(" ");
            jLabel3.setText(" ");
            jButton1.setEnabled(false);
            jButton2.setEnabled(false);
            jButton3.setEnabled(false);
            jButton4.setEnabled(false);
            jButton5.setEnabled(false);
            jButton6.setEnabled(false);
            jButton7.setEnabled(false);
            jButton8.setEnabled(false);
            jButton9.setEnabled(false);
            jButton10.setEnabled(false);
            jButton11.setEnabled(false);
            jButton12.setEnabled(false);
            jButton13.setEnabled(false);
            jButton14.setEnabled(false);
            jButton15.setEnabled(false);
            jButton16.setEnabled(false);            
            }
             
            
            if 
                    ( 
                    (("O".equals(jButton1.getText())) && ("O".equals(jButton5.getText())) && ("O".equals(jButton9.getText())) && ("O".equals(jButton13.getText()))) ||
                    (("O".equals(jButton1.getText())) && ("O".equals(jButton2.getText())) && ("O".equals(jButton3.getText())) && ("O".equals(jButton4.getText()))) ||
                    (("O".equals(jButton2.getText())) && ("O".equals(jButton6.getText())) && ("O".equals(jButton10.getText())) && ("O".equals(jButton14.getText()))) ||
                    (("O".equals(jButton3.getText())) && ("O".equals(jButton7.getText())) && ("O".equals(jButton11.getText())) && ("O".equals(jButton15.getText()))) ||
                    (("O".equals(jButton4.getText())) && ("O".equals(jButton8.getText())) && ("O".equals(jButton12.getText())) && ("O".equals(jButton16.getText()))) ||
                    (("O".equals(jButton5.getText())) && ("O".equals(jButton6.getText())) && ("O".equals(jButton7.getText())) && ("O".equals(jButton8.getText()))) ||
                    (("O".equals(jButton9.getText())) && ("O".equals(jButton10.getText()))&&("O".equals(jButton11.getText())) && ("O".equals(jButton12.getText()))) ||
                    (("O".equals(jButton13.getText()))&& ("O".equals(jButton14.getText()))&&("O".equals(jButton15.getText())) && ("O".equals(jButton16.getText()))) ||
                    (("O".equals(jButton1.getText())) && ("O".equals(jButton6.getText())) &&("O".equals(jButton11.getText())) && ("O".equals(jButton16.getText()))) ||
                    (("O".equals(jButton4.getText())) && ("O".equals(jButton7.getText())) && ("O".equals(jButton10.getText())) && ("O".equals(jButton13.getText()))) ||
                    (("O".equals(jButton1.getText())) && ("O".equals(jButton5.getText())) && ("O".equals(jButton9.getText())) && ("O".equals(jButton13.getText()))) 
                    )
            {
            jLabel4.setText("Player O wins");
            jLabel2.setText(" ");
            jLabel3.setText(" ");
            jButton1.setEnabled(false);
            jButton2.setEnabled(false);
            jButton3.setEnabled(false);
            jButton4.setEnabled(false);
            jButton5.setEnabled(false);
            jButton6.setEnabled(false);
            jButton7.setEnabled(false);
            jButton8.setEnabled(false);
            jButton9.setEnabled(false);
            jButton10.setEnabled(false);
            jButton11.setEnabled(false);
            jButton12.setEnabled(false);
            jButton13.setEnabled(false);
            jButton14.setEnabled(false);
            jButton15.setEnabled(false);
            jButton16.setEnabled(false);            
            }

        }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jButton11 = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        jButton12 = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        jButton13 = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jButton14 = new javax.swing.JButton();
        jPanel16 = new javax.swing.JPanel();
        jButton15 = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jButton16 = new javax.swing.JButton();
        resetGame = new javax.swing.JButton();
        label2 = new java.awt.Label();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        resetGame1 = new javax.swing.JButton();

        label1.setText("label1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 102));
        setFont(new java.awt.Font("Consolas", 0, 36)); // NOI18N
        setForeground(new java.awt.Color(0, 0, 0));
        setMaximizedBounds(new java.awt.Rectangle(0, 0, 739, 653));
        setMaximumSize(new java.awt.Dimension(739, 653));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ttt4.png"))); // NOI18N
        jLabel1.setText("INSERT LOGO HERE");
        jLabel1.setMaximumSize(new java.awt.Dimension(5, 5));
        jLabel1.setMinimumSize(new java.awt.Dimension(5, 5));
        jLabel1.setPreferredSize(new java.awt.Dimension(10, 10));

        jPanel2.setPreferredSize(new java.awt.Dimension(463, 463));
        jPanel2.setLayout(new java.awt.GridLayout(4, 4));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel1.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton1.setAlignmentY(0.3F);
        jButton1.setAutoscrolls(true);
        jButton1.setBorderPainted(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setDefaultCapable(false);
        jButton1.setHideActionText(true);
        jButton1.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton1.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel1);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel3.setLayout(new java.awt.BorderLayout());

        jButton2.setBackground(new java.awt.Color(204, 204, 204));
        jButton2.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton2.setAlignmentY(0.3F);
        jButton2.setAutoscrolls(true);
        jButton2.setBorderPainted(false);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.setDefaultCapable(false);
        jButton2.setHideActionText(true);
        jButton2.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton2.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel3);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel4.setLayout(new java.awt.BorderLayout());

        jButton3.setBackground(new java.awt.Color(204, 204, 204));
        jButton3.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton3.setAlignmentY(0.3F);
        jButton3.setAutoscrolls(true);
        jButton3.setBorderPainted(false);
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.setDefaultCapable(false);
        jButton3.setHideActionText(true);
        jButton3.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton3.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton3, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel4);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel5.setLayout(new java.awt.BorderLayout());

        jButton4.setBackground(new java.awt.Color(204, 204, 204));
        jButton4.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton4.setAlignmentY(0.3F);
        jButton4.setAutoscrolls(true);
        jButton4.setBorderPainted(false);
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.setDefaultCapable(false);
        jButton4.setHideActionText(true);
        jButton4.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton4.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton4, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel5);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel6.setLayout(new java.awt.BorderLayout());

        jButton5.setBackground(new java.awt.Color(204, 204, 204));
        jButton5.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton5.setAlignmentY(0.3F);
        jButton5.setAutoscrolls(true);
        jButton5.setBorderPainted(false);
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.setDefaultCapable(false);
        jButton5.setHideActionText(true);
        jButton5.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton5.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton5, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel6);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel7.setLayout(new java.awt.BorderLayout());

        jButton6.setBackground(new java.awt.Color(204, 204, 204));
        jButton6.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton6.setAlignmentY(0.3F);
        jButton6.setAutoscrolls(true);
        jButton6.setBorderPainted(false);
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.setDefaultCapable(false);
        jButton6.setHideActionText(true);
        jButton6.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton6.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton6, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel7);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel8.setLayout(new java.awt.BorderLayout());

        jButton7.setBackground(new java.awt.Color(204, 204, 204));
        jButton7.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton7.setAlignmentY(0.3F);
        jButton7.setAutoscrolls(true);
        jButton7.setBorderPainted(false);
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.setDefaultCapable(false);
        jButton7.setHideActionText(true);
        jButton7.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton7.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton7, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel8);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel9.setLayout(new java.awt.BorderLayout());

        jButton8.setBackground(new java.awt.Color(204, 204, 204));
        jButton8.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton8.setAlignmentY(0.3F);
        jButton8.setAutoscrolls(true);
        jButton8.setBorderPainted(false);
        jButton8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton8.setDefaultCapable(false);
        jButton8.setHideActionText(true);
        jButton8.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton8.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton8, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel9);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel10.setLayout(new java.awt.BorderLayout());

        jButton9.setBackground(new java.awt.Color(204, 204, 204));
        jButton9.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton9.setAlignmentY(0.3F);
        jButton9.setAutoscrolls(true);
        jButton9.setBorderPainted(false);
        jButton9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton9.setDefaultCapable(false);
        jButton9.setHideActionText(true);
        jButton9.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton9.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton9, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel10);

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel11.setLayout(new java.awt.BorderLayout());

        jButton10.setBackground(new java.awt.Color(204, 204, 204));
        jButton10.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton10.setAlignmentY(0.3F);
        jButton10.setAutoscrolls(true);
        jButton10.setBorderPainted(false);
        jButton10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton10.setDefaultCapable(false);
        jButton10.setHideActionText(true);
        jButton10.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton10.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton10, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel11);

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel12.setLayout(new java.awt.BorderLayout());

        jButton11.setBackground(new java.awt.Color(204, 204, 204));
        jButton11.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton11.setAlignmentY(0.3F);
        jButton11.setAutoscrolls(true);
        jButton11.setBorderPainted(false);
        jButton11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton11.setDefaultCapable(false);
        jButton11.setHideActionText(true);
        jButton11.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton11.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel12.add(jButton11, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel12);

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel13.setLayout(new java.awt.BorderLayout());

        jButton12.setBackground(new java.awt.Color(204, 204, 204));
        jButton12.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton12.setAlignmentY(0.3F);
        jButton12.setAutoscrolls(true);
        jButton12.setBorderPainted(false);
        jButton12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton12.setDefaultCapable(false);
        jButton12.setHideActionText(true);
        jButton12.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton12.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel13.add(jButton12, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel13);

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel14.setLayout(new java.awt.BorderLayout());

        jButton13.setBackground(new java.awt.Color(204, 204, 204));
        jButton13.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton13.setAlignmentY(0.3F);
        jButton13.setAutoscrolls(true);
        jButton13.setBorderPainted(false);
        jButton13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton13.setDefaultCapable(false);
        jButton13.setHideActionText(true);
        jButton13.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton13.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel14.add(jButton13, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel14);

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel15.setLayout(new java.awt.BorderLayout());

        jButton14.setBackground(new java.awt.Color(204, 204, 204));
        jButton14.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton14.setAlignmentY(0.3F);
        jButton14.setAutoscrolls(true);
        jButton14.setBorderPainted(false);
        jButton14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton14.setDefaultCapable(false);
        jButton14.setHideActionText(true);
        jButton14.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton14.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel15.add(jButton14, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel15);

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel16.setLayout(new java.awt.BorderLayout());

        jButton15.setBackground(new java.awt.Color(204, 204, 204));
        jButton15.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton15.setAlignmentY(0.3F);
        jButton15.setAutoscrolls(true);
        jButton15.setBorderPainted(false);
        jButton15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton15.setDefaultCapable(false);
        jButton15.setHideActionText(true);
        jButton15.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton15.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton15, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel16);

        jPanel17.setBackground(new java.awt.Color(255, 255, 255));
        jPanel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel17.setLayout(new java.awt.BorderLayout());

        jButton16.setBackground(new java.awt.Color(204, 204, 204));
        jButton16.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        jButton16.setAlignmentY(0.3F);
        jButton16.setAutoscrolls(true);
        jButton16.setBorderPainted(false);
        jButton16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton16.setDefaultCapable(false);
        jButton16.setHideActionText(true);
        jButton16.setMargin(new java.awt.Insets(4, 18, 4, 18));
        jButton16.setPreferredSize(new java.awt.Dimension(40, 20));
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton16, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel17);

        resetGame.setBackground(new java.awt.Color(0, 0, 0));
        resetGame.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        resetGame.setForeground(new java.awt.Color(204, 204, 204));
        resetGame.setText("Restart");
        resetGame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetGameActionPerformed(evt);
            }
        });

        label2.setText("© Lynx");

        jLabel4.setFont(new java.awt.Font("Courier New", 1, 24)); // NOI18N
        jLabel4.setToolTipText("");

        jLabel3.setFont(new java.awt.Font("Courier New", 1, 24)); // NOI18N
        jLabel3.setText("X");

        jLabel2.setFont(new java.awt.Font("Courier New", 1, 24)); // NOI18N
        jLabel2.setText("Turn :");

        resetGame1.setBackground(new java.awt.Color(0, 0, 0));
        resetGame1.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        resetGame1.setForeground(new java.awt.Color(204, 204, 204));
        resetGame1.setText("Close");
        resetGame1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetGame1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 766, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(133, 133, 133)
                        .addComponent(resetGame)
                        .addGap(1, 1, 1)
                        .addComponent(resetGame1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(345, 345, 345))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(resetGame, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(resetGame1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 707, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        setSize(new java.awt.Dimension(824, 1044));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      
    jButton1.setText(move.turn);
    go();
    winner();
    jButton1.setEnabled(false); 
    jButton1.setBackground(Color.white);
    jButton1.setForeground(Color.black);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
              
    jButton2.setText(move.turn);
    go();
    winner();
    jButton2.setEnabled(false); 
    jButton2.setBackground(Color.white);
    jButton2.setForeground(Color.black);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
          
    jButton3.setText(move.turn);
    go();
    winner();
    jButton3.setEnabled(false); 
    jButton3.setBackground(Color.white);
    jButton3.setForeground(Color.black);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
          
    jButton4.setText(move.turn);
    go();
    winner();
    jButton4.setEnabled(false); 
    jButton4.setBackground(Color.white);
    jButton4.setForeground(Color.black);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
              
    jButton5.setText(move.turn);
    go();
    winner();
    jButton5.setEnabled(false); 
    jButton5.setBackground(Color.white);
    jButton5.setForeground(Color.black);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
                  
    jButton6.setText(move.turn);
    go();
    winner();
    jButton6.setEnabled(false); 
    jButton6.setBackground(Color.white);
    jButton6.setForeground(Color.black);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
                  
    jButton7.setText(move.turn);
    go();
    winner();
    jButton7.setEnabled(false); 
    jButton7.setBackground(Color.white);
    jButton7.setForeground(Color.black);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
                  
    jButton8.setText(move.turn);
    go();
    winner();
    jButton8.setEnabled(false); 
    jButton8.setBackground(Color.white);
    jButton8.setForeground(Color.black);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
                  
    jButton9.setText(move.turn);
    go();
    winner();
    jButton9.setEnabled(false); 
    jButton9.setBackground(Color.white);
    jButton9.setForeground(Color.black);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
                  
    jButton10.setText(move.turn);
    go();
    winner();
    jButton10.setEnabled(false); 
    jButton10.setBackground(Color.white);
    jButton10.setForeground(Color.black);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
                  
    jButton11.setText(move.turn);
    go();
    winner();
    jButton11.setEnabled(false); 
    jButton11.setBackground(Color.white);
    jButton11.setForeground(Color.black);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
                  
    jButton12.setText(move.turn);
    go();
    winner();
    jButton12.setEnabled(false); 
    jButton12.setBackground(Color.white);
    jButton12.setForeground(Color.black);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
                  
    jButton13.setText(move.turn);
    go();
    winner();
    jButton13.setEnabled(false); 
    jButton13.setBackground(Color.white);
    jButton13.setForeground(Color.black);
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
                  
    jButton14.setText(move.turn);
    go();
    winner();
    jButton14.setEnabled(false); 
    jButton14.setBackground(Color.white);
    jButton14.setForeground(Color.black);
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
                      
    jButton15.setText(move.turn);
    go();
    winner();
    jButton15.setEnabled(false); 
    jButton15.setBackground(Color.white);
    jButton15.setForeground(Color.black);
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
                      
    jButton16.setText(move.turn);
    go();
    winner();
    jButton16.setEnabled(false); 
    jButton16.setBackground(Color.white);
    jButton16.setForeground(Color.black);
    }//GEN-LAST:event_jButton16ActionPerformed

    private void resetGameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetGameActionPerformed
    jButton1.setText(null);
    jButton1.setEnabled(true);
    jButton2.setText(null);
    jButton2.setEnabled(true);
    jButton3.setText(null);
    jButton3.setEnabled(true);
    jButton4.setText(null);
    jButton4.setEnabled(true);
    
    jButton5.setText(null);
    jButton5.setEnabled(true);
    jButton6.setText(null);
    jButton6.setEnabled(true);
    jButton7.setText(null);
    jButton7.setEnabled(true);
    jButton8.setText(null);
    jButton8.setEnabled(true);
    
    jButton9.setText(null);
    jButton9.setEnabled(true);
    jButton10.setText(null);
    jButton10.setEnabled(true);
    jButton11.setText(null);
    jButton11.setEnabled(true);
    jButton12.setText(null);
    jButton12.setEnabled(true);
    
    jButton13.setText(null);
    jButton13.setEnabled(true);
    jButton14.setText(null);
    jButton14.setEnabled(true);
    jButton15.setText(null);
    jButton15.setEnabled(true);
    jButton16.setText(null);
    jButton16.setEnabled(true);
    jLabel4.setText(" ");
    jLabel2.setText("Turn :");
    jLabel3.setText("X");
   
    move.turn = "X";
    move.count = 0;
    
    }//GEN-LAST:event_resetGameActionPerformed

    private void resetGame1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetGame1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_resetGame1ActionPerformed
  
    
    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private javax.swing.JButton resetGame;
    private javax.swing.JButton resetGame1;
    // End of variables declaration//GEN-END:variables
}
