/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lynx
 */
public class move {
    public static String turn = "X";
    public static int count = 0;
    public static String getTurn()
    {
      count ++;
      if (count == 2) 
      {
        if (((turn).equals("X")))	       	    	    		       	     	
        {	 
        turn = "O";
        }
        else {
          turn = "X";
        }
        
      count = 0;
      }
      
      return turn;
    }
}
